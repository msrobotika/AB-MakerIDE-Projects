# Gasolina MS · CYD

[← Catálogo](../../README.md) · [AB MakerIDE SUPER](https://github.com/msrobotika/AB-MakerIDE-SUPER)

Las **gasolineras públicas más baratas de tu pueblo**, con precios oficiales del Ministerio, para la **CYD ESP32-2432S028R** (ILI9341 horizontal 320 × 240 y táctil resistivo XPT2046). Sin cuenta, sin clave de API y sin geolocalización. Eliges un municipio y un combustible, y la placa compara sus precios publicados.

Hecho con AB MakerIDE. Un único archivo: [GasolinaMS/GasolinaMS.ino](GasolinaMS/GasolinaMS.ino). Pantalla, pines, calibración, colores, brillo y gestos adaptados de Kilovatio MS. No se necesita tarjeta SD ni PSRAM.

## Pantallas

Desliza a izquierda o derecha. Los puntos inferiores indican la pantalla.

| Pantalla | Qué muestra |
|---|---|
| AHORA | Marca y dirección de la estación pública más barata, precio en €/L, combustible, céntimos por debajo de la media y ahorro orientativo para los litros elegidos. Hora oficial del dato; si corresponde a otra fecha, indica «Datos anteriores» con fecha y hora. |
| TOP 5 | Hasta cinco estaciones ordenadas de menor a mayor precio, de verde a ámbar. Solo aparecen las que tienen precio válido y venta pública. |
| TENDENCIA | Mínimo y media durante los últimos 14 días naturales. Compara hoy con ayer; si falta ayer no usa otro día. Con menos de dos muestras pide volver mañana. Los huecos no se rellenan ni se unen en la gráfica. |
| AJUSTES | Combustible y litros actuales, actualizar ahora, QR de la web local, brillo automático o fijo y recalibración táctil. Mantén 2 s el botón Wi-Fi para abrir el portal. |

La actualización es cada **30 minutos** y al tocar **Actualizar ahora**. Si falla, aparece un error con **Reintentar**; además reintenta a los 2 minutos. Una respuesta incompleta no sustituye la última descarga válida. Sin estaciones públicas con precio, lo indica sin inventar un ahorro.

| LED RGB | Significado |
|---|---|
| Verde | Descarga correcta; mínimo de hoy más barato o igual que ayer. Si todavía no hay comparación válida, solo indica descarga correcta. |
| Ámbar | Mínimo de hoy más caro que el de ayer. |
| Rojo intermitente | Error de actualización o de guardado del histórico. |
| Azul | Portal de configuración Wi-Fi. |
| Apagado | Sin selección o sin precios públicos disponibles. |

El histórico es propio de esta placa: **no descarga precios históricos del Ministerio**. Guarda una muestra por día, después de las 08:00 (hora peninsular), y la reemplaza con la última descarga válida del día. Solo registra datos cuya fecha oficial sea la de hoy. Se conserva en NVS al reiniciar. Cambiar de pueblo o combustible reinicia el histórico; cambiar solo los litros lo conserva.

## Primera puesta en marcha y configuración

1. Toca el centro de las tres cruces para calibrar. Se guarda en NVS y se puede repetir desde AJUSTES.
2. Sin credenciales guardadas, la placa crea **Gasolina-MS**, con contraseña nueva, y muestra un QR para conectarte desde el móvil. El LED está azul.
3. Abre el portal que ofrece el móvil; si no aparece, entra en `http://192.168.4.1/`. Escribe el nombre de tu red de **2,4 GHz** y su clave. El portal solo configura Wi-Fi. La placa se reinicia y sincroniza su reloj por NTP.
4. Conecta el móvil a tu red habitual. La placa muestra **«Elige tu pueblo: escanea el QR»**. Ese QR y el de AJUSTES abren la web de la placa en su IP local. No confundirlo con el QR para conectarse al AP.
5. Elige provincia y después municipio, combustible y litros del depósito (**50 L** por defecto; de 1 a 200 L). La placa obtiene los listados oficiales y comprueba la pertenencia del municipio antes de guardar. Si falla una lista, usa **Recargar listas**.
6. Pulsa Guardar. La selección queda en Preferences y se solicita una descarga nueva. Los cambios de litros se reflejan en el ahorro.

El móvil y la placa deben estar en la misma red; el aislamiento de clientes o una red de invitados pueden impedir acceder. La URL de ajustes se imprime **una sola vez al arrancar conectado**, a 115200 baudios; el QR se adapta si el router cambia la IP. No necesita Internet el navegador: las peticiones al Ministerio las hace la placa. Sí necesita salida a Internet la CYD y hora NTP válida para verificar HTTPS.

Si no conecta tras unos 20 segundos, abre de nuevo el portal. Para cambiar de Wi-Fi, mantén 2 s su botón en AJUSTES. La nueva red solo se escribe al enviar el formulario; el dispositivo conserva las credenciales anteriores hasta entonces.

## Datos y licencia de los datos

Fuente: **Ministerio para la Transición Ecológica y el Reto Demográfico**, Servicios REST de Carburantes, difundidos como datos abiertos. Consulta también [datos.gob.es: reutilización de información de carburantes](https://datos.gob.es/es/noticias/reutilizacion-de-informacion-del-sector-publico-apps-de-combustible).

Base: `https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes`.

| Consulta | Ruta |
|---|---|
| Provincias | `/Listados/Provincias/` (campo oficial `IDPovincia`, con esa errata) |
| Municipios de provincia | `/Listados/MunicipiosPorProvincia/{IDProvincia}` |
| Productos | `/Listados/ProductosPetroliferos/` |
| Precios del municipio y producto | `/EstacionesTerrestres/FiltroMunicipioProducto/{IDMunicipio}/{IDProducto}` |

Todas las peticiones envían `Accept: application/json`. Los precios usan coma decimal. Se excluyen venta restringida (`R`), venta distinta de `P`, precios vacíos y precios mal formados o no positivos. La media es aritmética de **todas** las estaciones públicas con precio válido, no solo de las cinco primeras. El ahorro es `(media − mínimo) × litros`, sin sumar desplazamiento ni descuentos particulares.

| ID verificado el 9 nov 2026 | Combustible |
|---|---|
| 1 | Gasolina 95 E5 |
| 3 | Gasolina 98 E5 |
| 4 | Gasóleo A (nombre oficial: Gasóleo A habitual) |
| 5 | Gasóleo Premium |
| 17 | GLP (nombre oficial: Gases licuados del petróleo) |

IDs confirmados contra el [listado oficial de productos](https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/Listados/ProductosPetroliferos/) con cabecera JSON. La respuesta de Madrid se comprobó por TLS y HTTP/1.0 sin codificación chunked. El sketch analiza el flujo con **ArduinoJson 7 Filter por estación**, sin cargar la respuesta completa: solo mantiene cinco estaciones, recuento, suma, mínimo y máximo. No conserva coordenadas ni horarios: una estación publicada puede estar cerrada a esa hora.

HTTPS valida nombre de servidor, fechas y cadena con `setCACert`. Incluye la **DigiCert Global Root G2 real**, obtenida del almacén de confianza distribuido con Node, y contrastada con la [huella publicada por DigiCert](https://knowledge.digicert.com/general-information/digicert-trusted-root-authority-certificates):

`CB3CCBB76031E5E0138F8DD39A23F9DE47FFC35E43C1144CEA27D46A5AB1CB5F`

No hay marcador pendiente ni conexión insegura. La conexión de escritorio al servicio con **solo esta CA** funcionó. Si el Ministerio cambia la cadena, habrá que revisar la CA del sketch.

La reutilización de los datos está permitida **citando la fuente**, indicando su fecha de actualización, sin desnaturalizarlos ni sugerir patrocinio o respaldo del organismo. Consulta las condiciones originales del Ministerio y [datos.gob.es](https://datos.gob.es/es/noticias/reutilizacion-de-informacion-del-sector-publico-apps-de-combustible). La licencia MIT del programa no cambia las condiciones de los datos.

## Privacidad y límites

- Solo se usa el municipio que eliges. Sin GPS, sin ubicación del móvil, sin telemetría ni cuentas. El servicio oficial recibe las consultas de provincia, municipio y producto desde tu conexión.
- Pantalla y serie no muestran el nombre de tu Wi-Fi. El formulario de alta necesita que lo escribas, pero no lo devuelve en la confirmación ni lo copia a los ajustes LAN.
- Credenciales, calibración, selección y tendencia se guardan en la placa (NVS). Este sketch no cifra NVS. La web de configuración usa HTTP local, sin recursos externos; úsala en una red de confianza. El AP lleva clave aleatoria.
- Una línea serie por intento: municipio, producto, recuento, mínimo, media, fecha/hora oficial y estado. En error usa cifras cero y hora `--`; no presenta las cifras anteriores como recién descargadas.
- La fecha de la API corresponde al conjunto publicado; no acredita cuándo cambió cada surtidor. La renovación de la placa no acelera la declaración de precios por las estaciones.
- El pie recuerda: **«Precios oficiales del Ministerio (datos abiertos). Pueden tardar en actualizarse: confirma en el surtidor.»** No se garantiza un precio, apertura actual, disponibilidad ni condiciones de pago.
- La zona horaria es Europe/Madrid, como Kilovatio: en Canarias la hora mostrada es peninsular. Si no hay hora válida, no se omite la validación TLS: aparece un error y se reintenta.
- Mientras se realiza una consulta HTTPS, el servidor y el táctil pueden esperar al tiempo de red (15 s de espera por lectura). Rendimiento, consumo real de memoria y lectura de QR pendientes en placa.

## Hardware y pines

| Elemento | Pines GPIO |
|---|---|
| Pantalla ILI9341 (HSPI) | SCLK 14, MISO 12, MOSI 13, CS 15, DC 2, retroiluminación 21 (PWM) |
| Táctil XPT2046 (VSPI) | CLK 25, MISO 39, MOSI 32, CS 33, IRQ 36 |
| LED RGB, activo a nivel bajo | R 4, G 16, B 17 |
| Sensor de luz (LDR) | 34, brillo automático |
| Altavoz | 26, reservado; no se usa |
| microSD | CS 5 en alto; no se monta |

ILI9341 a 40 MHz, rotación 1 en LCD y táctil. Calibración afín de tres puntos, igual que Kilovatio. Brillo fijo 230/255 o automático con LDR (mínimo 35/255).

Referencia: [ESP32-Cheap-Yellow-Display](https://github.com/witnessmenow/ESP32-Cheap-Yellow-Display/blob/main/PINS.md). Otras revisiones, pantallas ST7789 o modelos capacitivos necesitan adaptación.

## Compilar y cargar

1. Abre `GasolinaMS/GasolinaMS.ino` en AB MakerIDE SUPER.
2. Selecciona **ESP32 Dev Module** (`esp32:esp32:esp32`, núcleo esp32 **3.x**).
3. Instala **Adafruit GFX**, **Adafruit ILI9341**, **XPT2046_Touchscreen** (Paul Stoffregen) y **ArduinoJson 7**. WiFi, WebServer, DNSServer, Preferences, HTTPClient, WiFiClientSecure y el QR se incluyen con esp32. No requiere pestañas `.h` propias.
4. Compila y graba con el esquema de particiones por defecto (ocupa el 93 %).
5. Cuando decidas probarlo, selecciona tu puerto y carga. Cargar sustituye el firmware de la placa. **En esta entrega no se ha cargado nada.**

Desde la raíz del repositorio, PowerShell:

```powershell
& 'C:\Program Files\Arduino CLI\arduino-cli.exe' compile --fqbn esp32:esp32:esp32 --build-path examples/gasolina-ms-cyd/.build examples/gasolina-ms-cyd/GasolinaMS
```

Solo si informa de falta de espacio, cambia el FQBN a `esp32:esp32:esp32:PartitionScheme=huge_app`. Borra la carpeta `.build` de este proyecto al terminar.

Comprobaciones de escritorio, con Node 24:

```powershell
node examples/gasolina-ms-cyd/tests/verificar.mjs
# Añadir --red verifica también los cuatro servicios y TLS reales.
```

## Evidencia

- 9 nov 2026: compilado con el núcleo esp32 3.3.12 y la partición por defecto (1 219 339 bytes de programa, 93 %) y grabado en una CYD por COM4 con escritura verificada por hash.
- En la placa real, con Madrid y Gasolina 95 E5: 233 gasolineras públicas descargadas del Ministerio, mínimo 1,529 €/L y media 1,717 €/L (datos de las 18:28 y 18:45). Portal Wi-Fi, página de ajustes desde el móvil, pantallas AHORA y TOP 5 y capturas por USB comprobados.
- Tras la primera prueba se corrigieron cuatro cosas: la lista de pueblos llegaba rota y tardaba ~25 s (ahora se descarga entera, menos de 1 s); la página de ajustes no respondía mientras se leían los precios byte a byte (ahora se leen a trozos de 1 kB); al guardar se volvía a pedir la lista al Ministerio (ahora se usa la copia recién enviada); y si la placa se reiniciaba, guardar decía «Vuelve a abrir los ajustes» (ahora pide un permiso nuevo en cada guardado).
- Detalle de la red verificada desde el escritorio en [specs/red-verificada.json](specs/red-verificada.json) y Spec Kit en [specs/](specs/).

**Pendiente de comprobar:** la pantalla TENDENCIA con varios días de datos y la estabilidad durante días.

## Licencia

MIT, copia exacta de [LICENSE](LICENSE) de Kilovatio MS. Ayudantes de pantalla y calibración de AB MakerIDE / MS Robotika, también MIT. Las bibliotecas conservan sus licencias. Los precios abiertos pertenecen a la fuente oficial y se reutilizan con atribución; el Ministerio no participa ni respalda este proyecto.
