/*
  Gasolina MS · AB MakerIDE / MS Robotika
  Las gasolineras públicas más baratas de tu pueblo, según el Ministerio.
  CYD ESP32-2432S028R, ILI9341 horizontal 320x240, táctil XPT2046.
  Desliza: AHORA, TOP 5, TENDENCIA y AJUSTES. Renovación cada 30 minutos.
  LED: verde si baja o iguala ayer; ámbar si sube; rojo intermitente en error.

  Datos abiertos del Ministerio para la Transición Ecológica y el Reto Demográfico.
  API pública sedeaplicaciones.minetur.gob.es, sin cuenta ni clave.
  HTTPS validado con DigiCert Global Root G2, incluida abajo. Nunca TLS inseguro.
  Primera vez: red Gasolina-MS y QR para configurar solo la Wi-Fi.
  Después: QR de ajustes en la red local para elegir pueblo, combustible y litros.
  Preferencias y credenciales se guardan solo en la placa (NVS).
  No muestra el nombre de la Wi-Fi ni usa geolocalización.

  Bibliotecas: Adafruit GFX, Adafruit ILI9341, XPT2046_Touchscreen (Paul Stoffregen),
  ArduinoJson 7. Placa: ESP32 Dev Module, núcleo esp32 3.x.
  Pines: github.com/witnessmenow/ESP32-Cheap-Yellow-Display/PINS.md
  Pantalla, calibración y ayudantes adaptados de Kilovatio MS.
  Precios orientativos: pueden tardar en actualizarse; confirma en el surtidor.
  Evidencia: pendiente de prueba en la placa.
  Licencia MIT, como el resto de AB MakerIDE.
*/
#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>
#include <XPT2046_Touchscreen.h>
#include <Fonts/FreeSansBold24pt7b.h>
#include <Fonts/FreeSansBold12pt7b.h>
#include <qrcode.h>
#include <time.h>

// ---------- Hardware de la CYD ----------
SPIClass lcdBus(HSPI), touchBus(VSPI);
Adafruit_ILI9341 lcd(&lcdBus, 2, 15, -1);
Adafruit_GFX* gfx = &lcd;  // Todo se dibuja por aquí; las capturas por USB lo cambian un momento.
XPT2046_Touchscreen touch(33, 36);
constexpr int LED_R = 4, LED_G = 16, LED_B = 17;  // activo a nivel bajo
constexpr int PIN_BL = 21, PIN_LDR = 34, PIN_SPK = 26;
constexpr int W = 320, H = 240;

// ---------- Colores ----------
constexpr uint16_t BG = 0x0861, PANEL = 0x18E4, LINE = 0x31A6, TXT = 0xFFFF, DIM = 0x9CF3;
constexpr uint16_t CHEAP = 0x2E8A, MID = 0xFE41, DEAR = 0xF8A6, ACC = 0x05FF, NEG = 0x6E7F;
constexpr uint16_t INK = 0x0000;  // texto sobre fondos de color: negro puro para que se lea bien

// ---------- CA real: DigiCert Global Root G2 ----------
// SHA-256: CB3CCBB76031E5E0138F8DD39A23F9DE47FFC35E43C1144CEA27D46A5AB1CB5F
const char ROOT_CA[] PROGMEM = R"PEM(-----BEGIN CERTIFICATE-----
MIIDjjCCAnagAwIBAgIQAzrx5qcRqaC7KGSxHQn65TANBgkqhkiG9w0BAQsFADBhMQswCQYD
VQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQu
Y29tMSAwHgYDVQQDExdEaWdpQ2VydCBHbG9iYWwgUm9vdCBHMjAeFw0xMzA4MDExMjAwMDBa
Fw0zODAxMTUxMjAwMDBaMGExCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMx
GTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xIDAeBgNVBAMTF0RpZ2lDZXJ0IEdsb2JhbCBS
b290IEcyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuzfNNNx7a8myaJCtSnX/
RrohCgiN9RlUyfuI2/Ou8jqJkTx65qsGGmvPrC3oXgkkRLpimn7Wo6h+4FR1IAWsULecYxps
MNzaHxmx1x7e/dfgy5SDN67sH0NO3Xss0r0upS/kqbitOtSZpLYl6ZtrAGCSYP9PIUkY92eQ
q2EGnI/yuum06ZIya7XzV+hdG82MHauVBJVJ8zUtluNJbd134/tJS7SsVQepj5WztCO7TG1F
8PapspUwtP1MVYwnSlcUfIKdzXOS0xZKBgyMUNGPHgm+F6HmIcr9g+UQvIOlCsRnKPZzFBQ9
RnbDhxSJITRNrw9FDKZJobq7nMWxM4MphQIDAQABo0IwQDAPBgNVHRMBAf8EBTADAQH/MA4G
A1UdDwEB/wQEAwIBhjAdBgNVHQ4EFgQUTiJUIBiV5uNu5g/6+rkS7QYXjzkwDQYJKoZIhvcN
AQELBQADggEBAGBnKJRvDkhj6zHd6mcY1Yl9PMWLSn/pvtsrF9+wX3N3KjITOYFnQoQj8kVn
NeyIv/iPsGEMNKSuIEyExtv4NeF22d+mQrvHRAiGfzZ0JFrabA0UWTW98kndth/Jsw1HKj2Z
L7tcu7XUIOGZX1NGFdtom/DzMNU+MeKNhJ7jitralj41E6Vf8PlwUHBHQRFXGU7Aj64GxJUT
Fy8bJZ918rGOmaFvE7FBcf6IKshPECBV1/MUReXgRPTqh5Uykw7+U0b6LJ3/iyK5S9kJRaTe
pLiaWN0bfVKfjllDiIGknibVb63dDcY3fe0Dkhvld1927jyNxF1WW6LZZm6zNTflMrY=
-----END CERTIFICATE-----
)PEM";

// ---------- Estado y tipos, antes de los ayudantes ----------
Preferences prefs;
WebServer web(80);
DNSServer dns;
const char BASE_URL[] = "https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes";
const uint8_t PRODUCT_IDS[] = {1, 3, 4, 5, 17};
const char* const FUELS[] = {"Gasolina 95 E5", "Gasolina 98 E5", "Gasóleo A", "Gasóleo Premium", "GLP"};
enum Screen { S_NOW, S_TOP, S_TREND, S_SETTINGS, S_COUNT };
const char* const SCREEN_NAMES[] = {"AHORA", "TOP 5", "TENDENCIA", "AJUSTES"};
struct Btn { int x, y, w, h; };
struct Config {
  uint32_t version = 1;
  char province[4] = "", town[8] = "", name[100] = "";
  uint16_t litres = 50;
  uint8_t fuel = 0;
};
struct Station { char brand[96] = "", address[160] = ""; int mills = 0; };
struct Summary {
  Station best[5];
  uint32_t count = 0;
  uint64_t sum = 0;
  int lo = 0, hi = 0, date = 0;
  char stamp[24] = "", clock[6] = "--:--";
};
struct Sample { int date = 0, lo = 0; float avg = 0; };
struct History {
  uint32_t version = 1;
  char town[8] = "";
  uint8_t fuel = 0, count = 0;
  Sample days[14];
};
Config config;
Summary data;
History history;
int screen = S_NOW;
bool portalMode = false, autoBright = true, refreshWanted = true, busy = false;
String apPass, settingsUrl, formToken;
float ax = 0, bx = 0, cx = 0, ay = 0, by = 0, cy = 0;
uint32_t lastFetchTry = 0, lastBright = 0, lastTick = 0, lastReconnect = 0, fetchedAt = 0;
char lastError[80] = "";
const Btn B_REFRESH = {8, 87, 150, 26}, B_BRIGHT = {8, 118, 150, 26};
const Btn B_CAL = {8, 149, 150, 26}, B_WIFI = {8, 180, 150, 16};
const Btn B_RETRY = {75, 151, 170, 30};
// ---------- Texto con acentos (fuente clasica CP437) y simbolo euro ----------
const uint8_t EURO[7] = {0x07, 0x08, 0x1E, 0x08, 0x1E, 0x08, 0x07};

void euro(int x, int y, uint8_t s, uint16_t fg, int32_t bg) {
  if (bg >= 0) gfx->fillRect(x, y, 6 * s, 8 * s, bg);
  for (int r = 0; r < 7; r++)
    for (int c = 0; c < 5; c++)
      if (EURO[r] & (0x10 >> c)) gfx->fillRect(x + c * s, y + r * s, s, s, fg);
}

uint8_t mapUtf8(const uint8_t*& p, bool& isEuro) {
  isEuro = false;
  uint8_t c = *p++;
  if (c < 0x80) return c;
  if (c == 0xC3) {
    if (!*p) return '?';
    switch (*p++) {
      case 0xA1: return 0xA0; case 0xA9: return 0x82; case 0xAD: return 0xA1;
      case 0xB3: return 0xA2; case 0xBA: return 0xA3; case 0xB1: return 0xA4;
      case 0x91: return 0xA5; case 0xBC: return 0x81; case 0x89: return 0x90;
      case 0x81: return 'A'; case 0x8D: return 'I'; case 0x93: return 'O'; case 0x9A: return 'U';
      default: return '?';
    }
  }
  if (c == 0xC2) {
    if (!*p) return '?';
    uint8_t d = *p++;
    return d == 0xBF ? 0xA8 : d == 0xA1 ? 0xAD : d == 0xBA ? 0xF8 : d == 0xB7 ? 0xFA : '?';
  }
  if (c == 0xE2 && p[0] == 0x82 && p[1] == 0xAC) { p += 2; isEuro = true; return ' '; }
  if (c == 0xE2 && p[0] == 0x88 && p[1] == 0x92) { p += 2; return '-'; }
  while ((*p & 0xC0) == 0x80) p++;
  return '?';
}

int textWidth(const char* s, uint8_t size) {
  int n = 0;
  bool e;
  for (const uint8_t* p = (const uint8_t*)s; *p;) { mapUtf8(p, e); n++; }
  return n * 6 * size;
}

void put(int x, int y, const char* s, uint16_t fg, uint8_t size = 1, int32_t bg = -1) {
  gfx->setFont();
  int cx0 = x;
  bool isEuro;
  for (const uint8_t* p = (const uint8_t*)s; *p;) {
    uint8_t ch = mapUtf8(p, isEuro);
    if (isEuro) euro(cx0, y, size, fg, bg);
    else gfx->drawChar(cx0, y, ch, fg, bg < 0 ? fg : (uint16_t)bg, size);
    cx0 += 6 * size;
  }
}

void putCenter(int cxm, int y, const char* s, uint16_t fg, uint8_t size = 1, int32_t bg = -1) {
  put(cxm - textWidth(s, size) / 2, y, s, fg, size, bg);
}

void putRight(int xr, int y, const char* s, uint16_t fg, uint8_t size = 1, int32_t bg = -1) {
  put(xr - textWidth(s, size), y, s, fg, size, bg);
}

void price(char* out, size_t n, float v, int decimals = 3) {
  snprintf(out, n, "%.*f", decimals, v);
  for (char* c = out; *c; c++) if (*c == '.') *c = ',';
}

void setLed(bool r, bool g, bool b) {
  digitalWrite(LED_R, r ? LOW : HIGH);
  digitalWrite(LED_G, g ? LOW : HIGH);
  digitalWrite(LED_B, b ? LOW : HIGH);
}

void updateBrightness() {
  int level = 230;
  if (autoBright) {
    int v = analogRead(PIN_LDR);  // con 0 dB: luz fuerte ~0, oscuridad sube
    level = constrain(map(v, 0, 450, 255, 35), 35, 255);
  }
  ledcWrite(PIN_BL, level);
}

// ---------- Tactil ----------
bool sampleRaw(int& x, int& y) {
  if (!touch.tirqTouched() || !touch.touched()) return false;
  TS_Point p = touch.getPoint();
  if (p.z < 250) return false;
  x = p.x;
  y = p.y;
  return true;
}

void toScreen(int rx, int ry, int& x, int& y) {
  x = lroundf(ax * rx + bx * ry + cx);
  y = lroundf(ay * rx + by * ry + cy);
}

void calibrate() {
  const int sx[3] = {24, 296, 24}, sy[3] = {24, 24, 216};
  int rx[3], ry[3];
  while (true) {
    for (int i = 0; i < 3; i++) {
      gfx->fillScreen(BG);
      putCenter(160, 100, "CALIBRAR TÁCTIL", ACC, 2);
      putCenter(160, 128, "Toca el centro de la cruz", TXT);
      gfx->drawFastHLine(sx[i] - 10, sy[i], 21, MID);
      gfx->drawFastVLine(sx[i], sy[i] - 10, 21, MID);
      gfx->drawCircle(sx[i], sy[i], 8, MID);
      int x, y;
      while (sampleRaw(x, y)) delay(10);
      int32_t sxr = 0, syr = 0;
      int n = 0;
      while (n < 12) {
        if (sampleRaw(x, y)) { sxr += x; syr += y; n++; }
        else { n = 0; sxr = syr = 0; }
        delay(12);
      }
      rx[i] = sxr / n;
      ry[i] = syr / n;
      while (sampleRaw(x, y)) delay(10);
      delay(150);
    }
    float ux = rx[1] - rx[0], uy = ry[1] - ry[0], vx = rx[2] - rx[0], vy = ry[2] - ry[0];
    float det = ux * vy - vx * uy;
    if (fabsf(det) < 10000) {
      putCenter(160, 160, "Repite las tres cruces", DEAR);
      delay(1000);
      continue;
    }
    ax = ((sx[1] - sx[0]) * vy - (sx[2] - sx[0]) * uy) / det;
    bx = (ux * (sx[2] - sx[0]) - vx * (sx[1] - sx[0])) / det;
    cx = sx[0] - ax * rx[0] - bx * ry[0];
    ay = ((sy[1] - sy[0]) * vy - (sy[2] - sy[0]) * uy) / det;
    by = (ux * (sy[2] - sy[0]) - vx * (sy[1] - sy[0])) / det;
    cy = sy[0] - ay * rx[0] - by * ry[0];
    prefs.putFloat("ax", ax); prefs.putFloat("bx", bx); prefs.putFloat("cx", cx);
    prefs.putFloat("ay", ay); prefs.putFloat("by", by); prefs.putFloat("cy", cy);
    prefs.putBool("cal", true);
    return;
  }
}

// ---------- Fechas, precios y memoria ----------
bool now(struct tm& t) { return getLocalTime(&t, 50); }
int ymdOf(const struct tm& t) { return (t.tm_year + 1900) * 10000 + (t.tm_mon + 1) * 100 + t.tm_mday; }

int previousDate(struct tm t) {
  t.tm_mday--; t.tm_hour = 12; t.tm_min = t.tm_sec = 0; t.tm_isdst = -1;
  mktime(&t);
  return ymdOf(t);
}

bool digits(const String& s, unsigned maxLen) {
  if (s.isEmpty() || s.length() > maxLen) return false;
  for (char c : s) if (c < '0' || c > '9') return false;
  return s.toInt() > 0;
}

// Milésimas de euro: evitar redondeos al ordenar y sumar.
bool parsePrice(const char* src, int& mills) {
  if (!src || !*src) return false;
  int whole = 0, fraction = 0, decimals = 0, n = 0;
  while (*src >= '0' && *src <= '9') {
    if (++n > 2) return false;
    whole = whole * 10 + *src++ - '0';
  }
  if (!n || *src++ != ',') return false;
  while (*src >= '0' && *src <= '9') {
    if (++decimals > 3) return false;
    fraction = fraction * 10 + *src++ - '0';
  }
  if (*src || !decimals) return false;
  while (decimals++ < 3) fraction *= 10;
  mills = whole * 1000 + fraction;
  return mills > 0;
}

void addStation(Summary& d, const Station& station) {
  d.sum += station.mills;
  if (!d.count || station.mills < d.lo) d.lo = station.mills;
  if (!d.count || station.mills > d.hi) d.hi = station.mills;
  int n = min((uint32_t)5, d.count), at = 0;
  while (at < n && d.best[at].mills <= station.mills) at++;
  if (at < 5) {
    for (int j = min(n, 4); j > at; j--) d.best[j] = d.best[j - 1];
    d.best[at] = station;
  }
  d.count++;
}

float average(const Summary& d) { return d.count ? (float)d.sum / d.count / 1000.0f : 0; }

bool parseStamp(const char* s, Summary& d) {
  int day, month, year, hour, minute, second, used = 0;
  if (sscanf(s, "%d/%d/%d %d:%d:%d%n", &day, &month, &year, &hour, &minute, &second, &used) != 6 ||
      s[used] || year < 2020 || year > 2099 || month < 1 || month > 12 || day < 1 || day > 31 ||
      hour < 0 || hour > 23 || minute < 0 || minute > 59 || second < 0 || second > 59) return false;
  struct tm t = {};
  t.tm_year = year - 1900; t.tm_mon = month - 1; t.tm_mday = day;
  t.tm_hour = 12; t.tm_isdst = -1;
  if (mktime(&t) == -1 || t.tm_mday != day || t.tm_mon != month - 1) return false;
  d.date = year * 10000 + month * 100 + day;
  strlcpy(d.stamp, s, sizeof(d.stamp));
  snprintf(d.clock, sizeof(d.clock), "%02d:%02d", hour, minute);
  return true;
}

void resetHistory() {
  history = History();
  strlcpy(history.town, config.town, sizeof(history.town));
  history.fuel = config.fuel;
}

bool saveHistory() { return prefs.putBytes("history", &history, sizeof(history)) == sizeof(history); }

void recordHistory() {
  struct tm t;
  if (!now(t)) return;
  struct tm cutoff = t;
  cutoff.tm_mday -= 13; cutoff.tm_hour = 12; cutoff.tm_isdst = -1;
  mktime(&cutoff);
  int n = 0;
  for (int i = 0; i < history.count; i++)
    if (history.days[i].date >= ymdOf(cutoff) && history.days[i].date <= ymdOf(t))
      history.days[n++] = history.days[i];
  bool trimmed = n != history.count;
  history.count = n;
  if (!data.count || t.tm_hour < 8 || data.date != ymdOf(t)) {
    if (trimmed && !saveHistory()) strlcpy(lastError, "No se pudo guardar la tendencia", sizeof(lastError));
    return;
  }
  Sample sample;
  sample.date = data.date; sample.lo = data.lo; sample.avg = average(data);
  if (n && history.days[n - 1].date == data.date) history.days[n - 1] = sample;
  else {
    if (n == 14) {
      for (int i = 1; i < 14; i++) history.days[i - 1] = history.days[i];
      n = 13;
    }
    history.days[n++] = sample;
    history.count = n;
  }
  if (!saveHistory()) strlcpy(lastError, "No se pudo guardar la tendencia", sizeof(lastError));
}

// Ayer natural, sin sustituirlo por otro día si falta.
bool yesterdayMin(int& mills) {
  struct tm t;
  if (!now(t) || data.date != ymdOf(t)) return false;
  int yesterday = previousDate(t);
  for (int i = 0; i < history.count; i++)
    if (history.days[i].date == yesterday) { mills = history.days[i].lo; return true; }
  return false;
}

void applyLed() {
  if (lastError[0]) { setLed((millis() / 400) % 2, false, false); return; }
  if (!data.count) { setLed(false, false, false); return; }
  int yesterday;
  bool dearer = yesterdayMin(yesterday) && data.lo > yesterday;
  setLed(dearer, true, false);
}

// ---------- HTTPS y lectura incremental ----------
bool beginApi(HTTPClient& http, WiFiClientSecure& client, const String& path, String& error) {
  struct tm t;
  if (WiFi.status() != WL_CONNECTED) { error = "Sin conexión Wi-Fi"; return false; }
  if (!now(t)) { error = "Sin hora: espera y reintenta"; return false; }
  client.setCACert(ROOT_CA);
  client.setTimeout(15000);
  client.setHandshakeTimeout(15);
  http.useHTTP10(true);  // El flujo recibe JSON sin codificación chunked.
  http.setReuse(false);
  http.setTimeout(15000);
  http.setConnectTimeout(10000);
  if (!http.begin(client, String(BASE_URL) + path)) { error = "No se pudo abrir HTTPS"; return false; }
  http.setUserAgent("Gasolina-MS/1.0 (CYD)");
  http.addHeader("Accept", "application/json");
  const char* headers[] = {"Transfer-Encoding"};
  http.collectHeaders(headers, 1);
  int code = http.GET();
  if (code != HTTP_CODE_OK) { error = "Ministerio: error HTTPS " + String(code); return false; }
  if (http.header("Transfer-Encoding").length()) { error = "Formato HTTP no admitido"; return false; }
  http.getStream().setTimeout(15000);
  return true;
}

// Lee la conexión segura a trozos de 1 kB: leer byte a byte tardaba ~30 s con Madrid y dejaba
// la página de ajustes sin responder mientras tanto.
class BufferedInput : public Stream {
 public:
  explicit BufferedInput(Client& c) : client(c) {}
  int available() override { return pos < len ? len - pos : client.available(); }
  int read() override { return fill() ? buf[pos++] : -1; }
  int peek() override { return fill() ? buf[pos] : -1; }
  size_t write(uint8_t) override { return 0; }
 private:
  bool fill() {
    if (pos < len) return true;
    uint32_t start = millis();
    while (millis() - start < 15000) {
      int got = client.read(buf, sizeof(buf));
      if (got > 0) { len = got; pos = 0; return true; }
      if (!client.connected() && !client.available()) return false;
      delay(1);
    }
    return false;
  }
  Client& client;
  uint8_t buf[1024];
  int len = 0, pos = 0;
};

int nextChar(Stream& input) {
  char c;
  while (input.readBytes(&c, 1) == 1) {
    if (c != ' ' && c != '\r' && c != '\n' && c != '\t') return (uint8_t)c;
  }
  return -1;
}

int peekChar(Stream& input) {
  while (true) {
    int c = input.peek();
    if (c == -1) {
      uint32_t start = millis();
      while ((c = input.peek()) == -1 && millis() - start < 15000) delay(1);
      if (c == -1) return -1;
    }
    if (c != ' ' && c != '\r' && c != '\n' && c != '\t') return c;
    input.read();
  }
}

bool arrayStart(Stream& input) {
  int c = nextChar(input);
  if (c == 0xEF) {  // BOM UTF-8 opcional.
    if (nextChar(input) != 0xBB || nextChar(input) != 0xBF) return false;
    c = nextChar(input);
  }
  return c == '[';
}

bool readPrices(Stream& input, Summary& out, String& error) {
  int c = nextChar(input);
  if (c == 0xEF) {
    if (nextChar(input) != 0xBB || nextChar(input) != 0xBF) return false;
    c = nextChar(input);
  }
  if (c != '{') { error = "Respuesta de precios no válida"; return false; }
  JsonDocument filter, key, value, item, discard;
  filter["Rótulo"] = true;
  filter["Dirección"] = true;
  filter["PrecioProducto"] = true;
  filter["Tipo Venta"] = true;
  discard.set(false);
  bool haveArray = false, haveDate = false, haveResult = false;
  while (true) {
    if (peekChar(input) != '"' || deserializeJson(key, input) || !key.is<const char*>()) break;
    if (nextChar(input) != ':') break;
    const char* name = key.as<const char*>();
    if (!strcmp(name, "ListaEESSPrecio")) {
      if (haveArray || nextChar(input) != '[') break;
      haveArray = true;
      if (peekChar(input) == ']') input.read();
      else while (true) {
        if (peekChar(input) != '{' || deserializeJson(item, input, DeserializationOption::Filter(filter)) ||
            !item.is<JsonObject>()) { error = "Datos incompletos: reintenta"; return false; }
        Station station;
        if (!strcmp(item["Tipo Venta"] | "", "P") && parsePrice(item["PrecioProducto"] | "", station.mills)) {
          strlcpy(station.brand, item["Rótulo"] | "Sin rótulo", sizeof(station.brand));
          strlcpy(station.address, item["Dirección"] | "Sin dirección", sizeof(station.address));
          addStation(out, station);
        }
        c = nextChar(input);
        if (c == ']') break;
        if (c != ',') { error = "Lista de precios incompleta"; return false; }
      }
    } else if (!strcmp(name, "Fecha") || !strcmp(name, "ResultadoConsulta")) {
      if (deserializeJson(value, input) || !value.is<const char*>()) break;
      if (!strcmp(name, "Fecha")) {
        if (haveDate || !parseStamp(value.as<const char*>(), out)) break;
        haveDate = true;
      } else {
        if (haveResult || strcmp(value.as<const char*>(), "OK")) break;
        haveResult = true;
      }
    } else if (deserializeJson(value, input, DeserializationOption::Filter(discard))) break;
    c = nextChar(input);
    if (c == '}') {
      if (haveArray && haveDate && haveResult) return true;
      break;
    }
    if (c != ',') break;
  }
  error = "Respuesta del Ministerio incompleta";
  return false;
}

// Listados: se descargan enteros (40 kB como mucho, Barcelona) porque leerlos letra a letra por TLS
// tardaba ~25 s y bloqueaba la página de ajustes. Si `out` no es nulo, deja ahí los elementos en JSON.
bool readList(const String& province, const String& wanted, String& found, String& error, String* out = nullptr) {
  WiFiClientSecure client;
  HTTPClient http;
  String path = province.isEmpty() ? "/Listados/Provincias/" : "/Listados/MunicipiosPorProvincia/" + province;
  if (!beginApi(http, client, path, error)) { http.end(); return false; }
  String body = http.getString();
  http.end();
  if (body.startsWith("\xEF\xBB\xBF")) body.remove(0, 3);  // BOM UTF-8 opcional.
  const char* idKey = province.isEmpty() ? "IDPovincia" : "IDMunicipio";
  const char* nameKey = province.isEmpty() ? "Provincia" : "Municipio";
  JsonDocument filter, doc;
  filter[0][idKey] = true; filter[0][nameKey] = true;
  bool ok = !deserializeJson(doc, body, DeserializationOption::Filter(filter)) && doc.is<JsonArray>();
  body = String();
  if (ok && out) *out = "";
  for (JsonObject item : doc.as<JsonArray>()) {
    if (!ok) break;
    const char* id = item[idKey] | "", *name = item[nameKey] | "";
    if (!digits(id, province.isEmpty() ? 2 : 6) || !*name || strlen(name) > 99) { ok = false; break; }
    if (wanted == id) found = name;
    if (out) {
      JsonDocument row; row["id"] = id; row["nombre"] = name;
      String one;  // serializeJson sustituye el contenido de un String: se añade aparte.
      serializeJson(row, one);
      if (out->length()) *out += ',';
      *out += one;
    }
  }
  if (!ok) error = "No se pudo leer la lista oficial";
  return ok;
}

void refreshPrices() {
  refreshWanted = false;
  if (!config.town[0] || busy) return;
  busy = true;
  lastFetchTry = millis();
  Summary candidate;
  String error;
  WiFiClientSecure client;
  HTTPClient http;
  String path = "/EstacionesTerrestres/FiltroMunicipioProducto/" + String(config.town) + "/" + PRODUCT_IDS[config.fuel];
  bool ok = beginApi(http, client, path, error);
  if (ok) { BufferedInput input(http.getStream()); input.setTimeout(15000); ok = readPrices(input, candidate, error); }
  http.end();
  if (ok) {
    data = candidate; fetchedAt = millis(); lastError[0] = 0;
    recordHistory();
  } else strlcpy(lastError, error.isEmpty() ? "Error al leer precios: reintenta" : error.c_str(), sizeof(lastError));
  // Una línea por intento; el error no se confunde con cifras recién descargadas.
  Serial.printf("GASOLINA municipio=%s producto=%u n=%lu min=%.3f media=%.3f hora=%s estado=%s\n",
                config.town, PRODUCT_IDS[config.fuel], (unsigned long)(ok ? data.count : 0),
                ok ? data.lo / 1000.0f : 0.0f, ok ? average(data) : 0.0f,
                ok ? data.stamp : "--", ok ? "OK" : "ERROR");
  busy = false;
  applyLed();
}

// ---------- Marco y texto corto ----------
String shortText(const char* src, int columns) {
  String out;
  bool truncated = textWidth(src, 1) / 6 > columns;
  int limit = truncated ? max(0, columns - 3) : columns;
  const uint8_t* p = (const uint8_t*)src;
  int n = 0;
  while (*p && n < limit) {
    const uint8_t* start = p;
    bool euroMark;
    mapUtf8(p, euroMark);
    while (start < p) out += (char)*start++;
    n++;
  }
  if (truncated) out += "...";
  return out;
}

void putShort(int x, int y, const char* s, int columns, uint16_t color, int size = 1) {
  String text = shortText(s, columns);
  put(x, y, text.c_str(), color, size);
}

void wifiIcon(int x, int y) {
  int bars = 0;
  if (WiFi.status() == WL_CONNECTED) {
    long r = WiFi.RSSI();
    bars = r > -60 ? 4 : r > -70 ? 3 : r > -80 ? 2 : 1;
  }
  for (int i = 0; i < 4; i++) {
    int h = 3 + i * 3;
    gfx->fillRect(x + i * 5, y + 12 - h, 3, h, i < bars ? TXT : LINE);
  }
}

void drawHeader() {
  gfx->fillRect(0, 0, W, 26, PANEL);
  gfx->fillRoundRect(8, 5, 13, 16, 2, MID);
  gfx->fillRect(10, 7, 9, 5, BG);  // surtidor
  gfx->drawLine(21, 9, 24, 12, MID); gfx->drawLine(24, 12, 24, 19, MID);
  put(28, 9, "GASOLINA MS", TXT, 1, PANEL);
  put(105, 9, SCREEN_NAMES[screen], ACC, 1, PANEL);
  struct tm t;
  char clock[8] = "--:--";
  if (now(t)) strftime(clock, sizeof(clock), "%H:%M", &t);
  putRight(286, 6, clock, TXT, 2, PANEL);
  wifiIcon(294, 7);
}

void drawFooter() {
  gfx->fillRect(0, 198, W, 42, BG);
  putCenter(160, 199, "Precios oficiales del Ministerio (datos abiertos).", DIM);
  putCenter(160, 209, "Pueden tardar en actualizarse:", DIM);
  putCenter(160, 219, "confirma en el surtidor.", DIM);
  for (int i = 0; i < S_COUNT; i++) {
    int x = 132 + i * 14;
    if (i == screen) gfx->fillRoundRect(x, 232, 10, 5, 2, ACC);
    else gfx->fillCircle(x + 5, 234, 2, LINE);
  }
}

void clearBody() { gfx->fillRect(0, 26, W, 172, BG); }
bool inside(const Btn& b, int x, int y) { return x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h; }

void button(const Btn& b, const char* label, uint16_t color = TXT) {
  gfx->fillRoundRect(b.x, b.y, b.w, b.h, 5, PANEL);
  gfx->drawRoundRect(b.x, b.y, b.w, b.h, 5, LINE);
  putCenter(b.x + b.w / 2, b.y + (b.h - 8) / 2, label, color);
}

static int qrX = 0, qrY = 0, qrMax = 130;
void drawQr(esp_qrcode_handle_t q) {
  int size = esp_qrcode_get_size(q);
  int scale = max(1, qrMax / (size + 8));
  int total = (size + 8) * scale;
  gfx->fillRect(qrX, qrY, total, total, TXT);
  for (int y = 0; y < size; y++)
    for (int x = 0; x < size; x++)
      if (esp_qrcode_get_module(q, x, y))
        gfx->fillRect(qrX + (x + 4) * scale, qrY + (y + 4) * scale, scale, scale, INK);
}

void showQr(const String& text, int x, int y, int maxSize) {
  qrX = x; qrY = y; qrMax = maxSize;
  esp_qrcode_config_t cfg = ESP_QRCODE_CONFIG_DEFAULT();
  cfg.display_func = drawQr;
  cfg.max_qrcode_version = 6;
  if (esp_qrcode_generate(&cfg, text.c_str()) != ESP_OK) put(x, y, "QR no disponible", DEAR);
}

void settingsQr(int x, int y, int maxSize) {
  if (WiFi.status() == WL_CONNECTED) showQr(settingsUrl, x, y, maxSize);
  else put(x, y, "Sin Wi-Fi", DEAR);
}

bool showMissing() {
  if (!config.town[0]) {
    putCenter(160, 35, "Elige tu pueblo: escanea el QR", TXT);
    settingsQr(104, 54, 120);
    putCenter(160, 182, "Con el móvil en la misma red Wi-Fi", DIM);
    return true;
  }
  if (lastError[0]) {
    putCenter(160, 57, "No se pudieron actualizar los precios", DEAR);
    putShort(10, 82, lastError, 50, MID);
    putCenter(160, 107, "Comprueba la conexión y reintenta", DIM);
    if (data.count) putCenter(160, 125, "Se conserva la última descarga válida", DIM);
    button(B_RETRY, "Reintentar", ACC);
    return true;
  }
  if (!data.count) {
    putCenter(160, 66, fetchedAt ? "Sin precios públicos para esta selección" : "Buscando precios...", TXT);
    putCenter(160, 96, "Puedes cambiar pueblo o combustible en AJUSTES", DIM);
    button(B_RETRY, "Actualizar ahora", ACC);
    return true;
  }
  return false;
}

void dataTime(int y) {
  char line[80];
  struct tm t;
  bool today = now(t) && data.date == ymdOf(t);
  if (today) snprintf(line, sizeof(line), "Datos del Ministerio · %s", data.clock);
  else snprintf(line, sizeof(line), "Datos anteriores · %s", data.stamp);
  putCenter(160, y, line, today ? DIM : MID);
}

// ---------- AHORA y TOP 5 ----------
void drawNow() {
  if (showMissing()) return;
  putShort(10, 32, config.name, 50, ACC);
  gfx->fillRoundRect(8, 45, 304, 82, 8, PANEL);
  putShort(18, 51, data.best[0].brand, 24, TXT, 2);
  putShort(18, 72, data.best[0].address, 47, DIM);
  char v[24], line[96];
  price(v, sizeof(v), data.lo / 1000.0f);
  gfx->setFont(&FreeSansBold24pt7b);
  gfx->setTextColor(CHEAP); gfx->setCursor(16, 119); gfx->print(v);
  gfx->setFont();
  put(200, 103, "€/L", TXT, 2);
  put(10, 132, FUELS[config.fuel], TXT);
  float saving = max(0.0f, average(data) - data.lo / 1000.0f);
  price(v, sizeof(v), saving * 100, 1);
  snprintf(line, sizeof(line), "%s céntimos menos que la media", v);
  put(10, 147, line, CHEAP);
  price(v, sizeof(v), saving * config.litres, 2);
  snprintf(line, sizeof(line), "Ahorras %s € en un depósito de %u L", v, config.litres);
  put(10, 162, line, CHEAP);
  snprintf(line, sizeof(line), "Frente a la media de %lu estaciones públicas", (unsigned long)data.count);
  put(10, 176, line, DIM);
  dataTime(188);
}

uint16_t rankColor(int rank) {
  int r = 5 + rank * 6, g = 52 - rank, b = 10 - rank * 2;
  return (r << 11) | (g << 5) | b;
}

void drawTop() {
  if (showMissing()) return;
  putShort(10, 32, config.name, 30, ACC);
  putRight(310, 32, FUELS[config.fuel], DIM);
  int n = min((uint32_t)5, data.count);
  for (int i = 0; i < n; i++) {
    int y = 48 + i * 29;
    uint16_t c = rankColor(i);
    gfx->fillRoundRect(8, y, 304, 26, 4, PANEL);
    gfx->fillRect(8, y + 3, 3, 20, c);
    putShort(17, y + 2, data.best[i].brand, 30, c);
    putShort(17, y + 15, data.best[i].address, 36, DIM);
    char v[16]; price(v, sizeof(v), data.best[i].mills / 1000.0f);
    putRight(306, y + 5, v, c, 2);
  }
}

// ---------- TENDENCIA ----------
int dayNumber(int date) {
  struct tm t = {};
  t.tm_year = date / 10000 - 1900; t.tm_mon = (date / 100) % 100 - 1; t.tm_mday = date % 100;
  t.tm_hour = 12; t.tm_isdst = -1;
  return lround((double)mktime(&t) / 86400.0);
}

void drawTrend() {
  if (showMissing()) return;
  putShort(10, 32, config.name, 50, ACC);
  if (history.count < 2) {
    putCenter(160, 82, "Vuelve mañana para ver la tendencia", TXT);
    putCenter(160, 108, "Una muestra al día, después de las 08:00", DIM);
    return;
  }
  int yesterday;
  char line[80], v[16];
  if (yesterdayMin(yesterday)) {
    int diff = data.lo - yesterday;
    put(10, 48, diff < 0 ? "Hoy más barata que ayer" : diff > 0 ? "Hoy más cara que ayer" : "Hoy igual que ayer", TXT);
    price(v, sizeof(v), abs(diff) / 10.0f, 1);
    snprintf(line, sizeof(line), "(%s%s cts)", diff < 0 ? "−" : diff > 0 ? "+" : "", v);
    putRight(310, 63, line, diff <= 0 ? CHEAP : MID);
  } else put(10, 48, "Sin comparación de hoy con ayer", DIM);
  float lo = 100, hi = 0;
  int firstDay = dayNumber(history.days[0].date), lastDay = dayNumber(history.days[history.count - 1].date);
  for (int i = 0; i < history.count; i++) {
    lo = min(lo, history.days[i].lo / 1000.0f);
    hi = max(hi, history.days[i].avg);
  }
  if (hi - lo < 0.01f) { hi += 0.005f; lo -= 0.005f; }
  auto yOf = [&](float p) { return 161 - (int)((p - lo) / (hi - lo) * 75); };
  for (int k = 0; k < 3; k++) {
    float p = lo + (hi - lo) * k / 2;
    int y = yOf(p);
    gfx->drawFastHLine(43, y, 266, PANEL);
    price(v, sizeof(v), p, 2); put(8, y - 3, v, DIM);
  }
  int px = 0, pyLo = 0, pyAvg = 0, previousDay = 0;
  for (int i = 0; i < history.count; i++) {
    int day = dayNumber(history.days[i].date);
    int x = 44 + (day - firstDay) * 260 / max(1, lastDay - firstDay);
    int yl = yOf(history.days[i].lo / 1000.0f), ya = yOf(history.days[i].avg);
    if (i && day == previousDay + 1) {  // No unir días ausentes.
      gfx->drawLine(px, pyLo, x, yl, CHEAP); gfx->drawLine(px, pyAvg, x, ya, ACC);
    }
    gfx->fillCircle(x, yl, 2, CHEAP); gfx->fillCircle(x, ya, 2, ACC);
    px = x; pyLo = yl; pyAvg = ya; previousDay = day;
  }
  snprintf(line, sizeof(line), "%02d/%02d", history.days[0].date % 100, history.days[0].date / 100 % 100);
  put(43, 170, line, DIM);
  int date = history.days[history.count - 1].date;
  snprintf(line, sizeof(line), "%02d/%02d", date % 100, date / 100 % 100);
  putRight(310, 170, line, DIM);
  put(72, 186, "Mínimo", CHEAP); put(145, 186, "Media · €/L", ACC);
}

// ---------- AJUSTES ----------
void drawSettings() {
  putShort(10, 32, config.name[0] ? config.name : "Elige tu pueblo", 50, ACC);
  put(10, 48, FUELS[config.fuel], TXT);
  char line[40]; snprintf(line, sizeof(line), "Depósito: %u L", config.litres);
  put(10, 63, line, DIM);
  put(174, 48, "Escanea y ajusta", TXT);
  settingsQr(174, 65, 132);
  button(B_REFRESH, "Actualizar ahora", ACC);
  button(B_BRIGHT, autoBright ? "Brillo: automático" : "Brillo: fijo", TXT);
  button(B_CAL, "Recalibrar táctil", TXT);
  button(B_WIFI, "Wi-Fi: mantener 2 s", MID);
}

void drawScreen() {
  drawHeader(); clearBody();
  switch (screen) {
    case S_NOW: drawNow(); break;
    case S_TOP: drawTop(); break;
    case S_TREND: drawTrend(); break;
    case S_SETTINGS: drawSettings(); break;
  }
  drawFooter();
}

void slideTo(int next, int dir) {
  for (int i = 0; i < 8; i++) {
    int x = dir > 0 ? W - (i + 1) * 40 : i * 40;
    gfx->fillRect(x, 26, 40, 172, PANEL); delay(8);
  }
  screen = (next + S_COUNT) % S_COUNT;
  drawScreen();
}

// ---------- Web local, sin recursos ni servicios externos ----------
const char PAGE_HEAD[] PROGMEM = R"HTML(<!doctype html><html lang="es"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Gasolina MS</title>
<style>body{font-family:system-ui,sans-serif;background:#0b1220;color:#e8eef7;max-width:460px;margin:auto;padding:20px}
h1{font-size:24px}input,select,button{width:100%;box-sizing:border-box;padding:12px;margin:6px 0 14px;border-radius:10px;
border:1px solid #334;background:#152033;color:#fff;font-size:16px}button{background:#00b4ff;color:#001;font-weight:700}
small{color:#9ab}a{color:#00b4ff}#estado{min-height:2em}</style>)HTML";

const char SETTINGS_PAGE[] PROGMEM = R"HTML(<h1>Gasolina MS</h1>
<p>Elige tu pueblo. No usamos tu ubicación.</p><p id="estado" role="status">Cargando ajustes...</p>
<form id="ajustes"><label for="provincia">Provincia</label><select id="provincia" required disabled></select>
<label for="municipio">Pueblo o ciudad</label><select id="municipio" required disabled></select>
<label for="producto">Combustible</label><select id="producto">
<option value="1">Gasolina 95 E5</option><option value="3">Gasolina 98 E5</option><option value="4">Gasóleo A</option>
<option value="5">Gasóleo Premium</option><option value="17">GLP</option></select>
<label for="litros">Litros del depósito</label><input id="litros" type="number" min="1" max="200" step="1" value="50" required>
<button id="guardar" disabled>Guardar</button></form><button id="reintentar" type="button">Recargar listas</button>
<small>Precios oficiales del Ministerio (datos abiertos). Pueden tardar en actualizarse: confirma en el surtidor.
Fuente: Ministerio para la Transición Ecológica y el Reto Demográfico. Aplicación independiente.</small>
<script>
const el=id=>document.getElementById(id);
let token='',generation=0;
async function request(url,options){
  const r=await fetch(url,options);
  const value=await r.json();
  if(!r.ok||!value.ok)throw new Error(value.error||'No se pudo cargar. Reintenta.');
  return value;
}
function options(id,items,selected){
  const select=el(id);select.replaceChildren();
  select.add(new Option('Elige una opción',''));
  for(const row of items)select.add(new Option(row.nombre,row.id));
  select.value=selected||'';select.disabled=false;
}
async function towns(selected){
  const mine=++generation,province=el('provincia').value;
  el('municipio').disabled=true;el('municipio').replaceChildren();el('guardar').disabled=true;
  if(!province)return;
  el('estado').textContent='Cargando pueblos...';
  try{
    const data=await request('/municipios?p='+encodeURIComponent(province));
    if(mine!==generation)return;
    options('municipio',data.items,selected);
    el('estado').textContent='Elige el pueblo y guarda.';
    el('guardar').disabled=false;
  }catch(e){if(mine===generation)el('estado').textContent=e.message;}
}
async function load(){
  el('guardar').disabled=true;el('provincia').disabled=true;el('municipio').disabled=true;
  el('estado').textContent='Cargando ajustes...';
  el('reintentar').disabled=true;
  try{
    const cfg=await request('/config');token=cfg.token;
    el('producto').value=String(cfg.producto);el('litros').value=cfg.litros;
    const data=await request('/provincias');options('provincia',data.items,cfg.provincia);
    if(cfg.provincia)await towns(cfg.municipio);
    else el('estado').textContent='Elige la provincia y después el pueblo.';
  }catch(e){el('estado').textContent=e.message;}
  finally{el('reintentar').disabled=false;}
}
el('provincia').addEventListener('change',()=>towns(''));
el('reintentar').addEventListener('click',load);
el('ajustes').addEventListener('submit',async event=>{
  event.preventDefault();el('guardar').disabled=true;el('estado').textContent='Comprobando y guardando...';
  try{
    // Permiso nuevo en cada guardado: si la placa se ha reiniciado, el de la página ya no vale.
    token=(await request('/config')).token;
    const body=new URLSearchParams({provincia:el('provincia').value,municipio:el('municipio').value,
      producto:el('producto').value,litros:el('litros').value,token});
    await request('/guardar',{method:'POST',body});el('estado').textContent='Guardado. La placa actualizará los precios.';}
  catch(e){el('estado').textContent=e.message;}
  finally{el('guardar').disabled=false;}
});
load();
</script></html>)HTML";

void jsonError(int status, const String& message) {
  JsonDocument doc; doc["ok"] = false; doc["error"] = message;
  String out; serializeJson(doc, out);
  web.send(status, "application/json; charset=utf-8", out);
}

void handleRoot() {
  web.sendHeader("Cache-Control", "no-store");
  String page = FPSTR(PAGE_HEAD);
  if (portalMode) {
    page += "<h1>Gasolina MS · Wi-Fi</h1><p>Conecta la placa a una red de 2,4 GHz. La clave se guarda solo en la placa.</p>"
            "<form method=post action=/wifi><label>Nombre de la red</label>"
            "<input name=s maxlength=32 required autocomplete=off><label>Contraseña</label>"
            "<input name=p type=password maxlength=63 autocomplete=off><input type=hidden name=token value='";
    page += formToken;
    page += "'><button>Guardar y conectar</button></form><small>MS Robotika · AB MakerIDE</small></html>";
  } else page += FPSTR(SETTINGS_PAGE);
  web.send(200, "text/html; charset=utf-8", page);
}

void handleWifiSave() {
  if (!portalMode || web.arg("token") != formToken) { jsonError(403, "Vuelve a abrir el portal"); return; }
  String s = web.arg("s"), p = web.arg("p");
  // No recortar el nombre: los espacios pueden pertenecer a la red.
  if (!s.length() || s.length() > 32 || (p.length() && (p.length() < 8 || p.length() > 63))) {
    web.send(400, "text/html; charset=utf-8", String(FPSTR(PAGE_HEAD)) +
             "<h1>Revisa los datos</h1><p>Escribe el nombre de la red y una clave de 8 a 63 caracteres, o vacía si es abierta.</p><a href=/>Volver</a>");
    return;
  }
  if (prefs.putString("ssid", s) != s.length() ||
      (prefs.putString("pass", p) != p.length())) {
    jsonError(500, "No se pudo guardar la Wi-Fi"); return;
  }
  web.send(200, "text/html; charset=utf-8", String(FPSTR(PAGE_HEAD)) +
           "<h1>Guardado</h1><p>La placa se reinicia. Conecta el móvil a tu red habitual y abre el QR de AJUSTES.</p>");
  delay(1200); ESP.restart();
}

void handleConfig() {
  if (portalMode) { jsonError(403, "Configura primero la Wi-Fi"); return; }
  JsonDocument doc;
  doc["ok"] = true; doc["token"] = formToken;
  doc["provincia"] = config.province; doc["municipio"] = config.town;
  doc["producto"] = PRODUCT_IDS[config.fuel]; doc["litros"] = config.litres;
  String out; serializeJson(doc, out);
  web.sendHeader("Cache-Control", "no-store");
  web.send(200, "application/json; charset=utf-8", out);
}

// Última lista enviada a la página (0 = provincias, 1 = pueblos de listKey[1]). Al guardar se valida con
// ella y no se vuelve a pedir al Ministerio, que a veces tarda decenas de segundos en responder.
String listCache[2], listKey[2];

String nameFromCache(int kind, const String& key, const String& id) {
  if (listCache[kind].isEmpty() || listKey[kind] != key) return "";
  String mark = "{\"id\":\"" + id + "\",\"nombre\":\"";
  int a = listCache[kind].indexOf(mark);
  if (a < 0) return "";
  a += mark.length();
  int b = listCache[kind].indexOf("\"}", a);
  return b < 0 ? "" : listCache[kind].substring(a, b);
}

void handleList(bool towns) {
  if (portalMode) { jsonError(403, "Configura primero la Wi-Fi"); return; }
  String province = towns ? web.arg("p") : "";
  if (towns && !digits(province, 2)) { jsonError(400, "Provincia no válida"); return; }
  int kind = towns ? 1 : 0;
  if (listCache[kind].isEmpty() || listKey[kind] != province) {
    String found, error, items;
    if (!readList(province, "", found, error, &items)) { jsonError(502, "No se pudo cargar la lista. Reintenta."); return; }
    listCache[kind] = items; listKey[kind] = province;
  }
  web.sendHeader("Cache-Control", "no-store");
  web.send(200, "application/json; charset=utf-8", "{\"items\":[" + listCache[kind] + "],\"ok\":true}");
}

void handleSettingsSave() {
  if (portalMode || web.arg("token") != formToken) { jsonError(403, "Vuelve a abrir los ajustes"); return; }
  String province = web.arg("provincia"), town = web.arg("municipio"), litres = web.arg("litros");
  String product = web.arg("producto");
  int fuel = -1;
  for (int i = 0; i < 5; i++) if (product == String(PRODUCT_IDS[i])) fuel = i;
  if (!digits(province, 2) || !digits(town, 6) || !digits(litres, 3) || litres.toInt() > 200 || fuel < 0) {
    jsonError(400, "Revisa pueblo, combustible y litros (1 a 200)"); return;
  }
  String officialProvince = nameFromCache(0, "", province), officialTown = nameFromCache(1, province, town), error;
  if ((officialProvince.isEmpty() && (!readList("", province, officialProvince, error) || officialProvince.isEmpty())) ||
      (officialTown.isEmpty() && (!readList(province, town, officialTown, error) || officialTown.isEmpty()))) {
    jsonError(400, error.isEmpty() ? "El pueblo no pertenece a esa provincia" : error); return;
  }
  Config next;
  strlcpy(next.province, province.c_str(), sizeof(next.province));
  strlcpy(next.town, town.c_str(), sizeof(next.town));
  strlcpy(next.name, officialTown.c_str(), sizeof(next.name));
  next.fuel = fuel; next.litres = litres.toInt();
  if (prefs.putBytes("config", &next, sizeof(next)) != sizeof(next)) { jsonError(500, "No se pudo guardar"); return; }
  bool changed = strcmp(config.town, next.town) || config.fuel != next.fuel;
  config = next;
  if (changed) {
    data = Summary(); fetchedAt = 0; lastError[0] = 0;
    resetHistory();
    if (!saveHistory()) strlcpy(lastError, "No se pudo guardar la tendencia", sizeof(lastError));
  }
  refreshWanted = true;
  web.send(200, "application/json; charset=utf-8", "{\"ok\":true}");
  drawScreen();
}

void startWeb() {
  web.on("/", HTTP_GET, handleRoot);
  web.on("/wifi", HTTP_POST, handleWifiSave);
  web.on("/config", HTTP_GET, handleConfig);
  web.on("/provincias", HTTP_GET, [] { handleList(false); });
  web.on("/municipios", HTTP_GET, [] { handleList(true); });
  web.on("/guardar", HTTP_POST, handleSettingsSave);
  web.onNotFound([] {
    if (portalMode) { web.sendHeader("Location", "http://192.168.4.1/"); web.send(302, "text/plain", ""); }
    else jsonError(404, "Página no encontrada");
  });
  web.begin();
}

void startPortal() {
  portalMode = true;
  WiFi.disconnect(true);
  WiFi.mode(WIFI_AP);
  char pass[9]; snprintf(pass, sizeof(pass), "%08lu", (unsigned long)(esp_random() % 100000000UL));
  apPass = pass;
  WiFi.softAP("Gasolina-MS", pass);
  dns.start(53, "*", WiFi.softAPIP());
  gfx->fillScreen(BG);
  gfx->fillRect(0, 0, W, 26, PANEL);
  put(10, 9, "GASOLINA MS · CONFIGURAR WI-FI", ACC, 1, PANEL);
  showQr("WIFI:T:WPA;S:Gasolina-MS;P:" + apPass + ";;", 8, 40, 150);
  put(170, 43, "1. Escanea el QR", TXT);
  put(170, 58, "   con el móvil", TXT);
  put(170, 79, "2. Abre el portal", TXT);
  put(170, 94, "   192.168.4.1", DIM);
  put(170, 115, "3. Escribe tu red", TXT);
  put(170, 130, "   y su clave", TXT);
  put(170, 153, "Red: Gasolina-MS", ACC);
  put(170, 169, "Clave:", ACC); put(210, 166, pass, MID, 2);
  drawFooter();
  setLed(false, false, true);
}

bool connectWifi() {
  String s = prefs.getString("ssid", ""), p = prefs.getString("pass", "");
  if (s.isEmpty()) return false;
  WiFi.mode(WIFI_STA);
  WiFi.setHostname("gasolina-ms");
  WiFi.setAutoReconnect(true);
  WiFi.begin(s.c_str(), p.c_str());
  gfx->fillScreen(BG);
  putCenter(160, 96, "GASOLINA MS", MID, 3);
  putCenter(160, 132, "Conectando a la Wi-Fi...", TXT);
  for (int i = 0; i < 40 && WiFi.status() != WL_CONNECTED; i++) {
    gfx->fillCircle(130 + (i % 5) * 15, 160, 4, ACC);
    if (i % 5 == 4) gfx->fillRect(120, 154, 80, 12, BG);
    delay(500);
  }
  return WiFi.status() == WL_CONNECTED;
}

// ---------- Gestos de Kilovatio ----------
bool touching = false, longFired = false;
int downX = 0, downY = 0, lastX = 0, lastY = 0;
uint32_t downAt = 0, upAt = 0;

void onTap(int x, int y) {
  if (screen == S_SETTINGS) {
    if (inside(B_REFRESH, x, y)) refreshWanted = true;
    else if (inside(B_BRIGHT, x, y)) { autoBright = !autoBright; prefs.putBool("auto", autoBright); updateBrightness(); }
    else if (inside(B_CAL, x, y)) calibrate();
    else return;
    drawScreen();
  } else if (inside(B_RETRY, x, y) && (lastError[0] || !data.count)) refreshWanted = true;
}

void onLongPress(int x, int y) {
  if (screen == S_SETTINGS && inside(B_WIFI, x, y)) startPortal();
}

void handleTouch() {
  int rx, ry;
  uint32_t t = millis();
  if (sampleRaw(rx, ry)) {
    int x, y; toScreen(rx, ry, x, y);
    if (!touching) { touching = true; longFired = false; downX = x; downY = y; downAt = t; }
    lastX = x; lastY = y; upAt = t;
    if (!longFired && t - downAt > 2000 && abs(x - downX) < 25 && abs(y - downY) < 25) {
      longFired = true; onLongPress(downX, downY);
    }
    return;
  }
  if (touching && t - upAt > 60) {
    touching = false;
    if (longFired || portalMode) return;
    int dx = lastX - downX, dy = lastY - downY;
    if (abs(dx) > 50 && abs(dx) > abs(dy)) slideTo(screen + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1);
    else if (abs(dx) < 15 && abs(dy) < 15) onTap(downX, downY);
  }
}

void loadPreferences() {
  if (prefs.getBytesLength("config") == sizeof(config)) {
    Config saved;
    prefs.getBytes("config", &saved, sizeof(saved));
    saved.province[sizeof(saved.province) - 1] = 0; saved.town[sizeof(saved.town) - 1] = 0;
    saved.name[sizeof(saved.name) - 1] = 0;
    if (saved.version == 1 && saved.fuel < 5 && saved.litres >= 1 && saved.litres <= 200 &&
        digits(saved.province, 2) && digits(saved.town, 6) && saved.name[0]) config = saved;
  }
  resetHistory();
  if (prefs.getBytesLength("history") == sizeof(history)) {
    History saved;
    prefs.getBytes("history", &saved, sizeof(saved)); saved.town[sizeof(saved.town) - 1] = 0;
    bool valid = saved.version == 1 && saved.count <= 14 && saved.fuel == config.fuel && !strcmp(saved.town, config.town);
    for (int i = 0; i < saved.count && valid; i++)
      valid = saved.days[i].date >= 20200101 && saved.days[i].date <= 20991231 && saved.days[i].lo > 0 &&
              isfinite(saved.days[i].avg) && saved.days[i].avg >= saved.days[i].lo / 1000.0f - 0.0001f &&
              (!i || saved.days[i].date > saved.days[i - 1].date);
    if (valid) history = saved;
  }
}

// ---------- Programa ----------
void setup() {
  Serial.begin(115200); delay(200);
  pinMode(LED_R, OUTPUT); pinMode(LED_G, OUTPUT); pinMode(LED_B, OUTPUT);
  setLed(false, false, false);
  pinMode(5, OUTPUT); digitalWrite(5, HIGH);  // microSD sin usar.
  ledcAttach(PIN_BL, 5000, 8); ledcWrite(PIN_BL, 230);
  analogSetPinAttenuation(PIN_LDR, ADC_0db);
  lcdBus.begin(14, 12, 13, 15); lcd.begin(40000000); lcd.setRotation(1); gfx->cp437(true);
  gfx->setTextWrap(false);
  touchBus.begin(25, 39, 32, 33); touch.begin(touchBus); touch.setRotation(1);
  prefs.begin("gasolina-ms", false);
  loadPreferences(); autoBright = prefs.getBool("auto", true);
  if (prefs.getBool("cal", false)) {
    ax = prefs.getFloat("ax"); bx = prefs.getFloat("bx"); cx = prefs.getFloat("cx");
    ay = prefs.getFloat("ay"); by = prefs.getFloat("by"); cy = prefs.getFloat("cy");
  } else calibrate();
  updateBrightness();
  char token[17]; snprintf(token, sizeof(token), "%08lx%08lx", (unsigned long)esp_random(), (unsigned long)esp_random());
  formToken = token;
  if (!connectWifi()) { startPortal(); startWeb(); return; }
  configTzTime("CET-1CEST,M3.5.0,M10.5.0/3", "es.pool.ntp.org", "pool.ntp.org", "time.google.com");
  settingsUrl = "http://" + WiFi.localIP().toString() + "/";
  Serial.printf("GASOLINA ajustes=%s\n", settingsUrl.c_str());  // Única IP en serie.
  startWeb();
  putCenter(160, 180, "Sincronizando hora...", DIM);
  struct tm t;
  for (int i = 0; i < 60 && !now(t); i++) { web.handleClient(); delay(100); }
  drawScreen();
}

// Capturas por USB para la documentación y los vídeos (no hace falta tocar la pantalla):
// "MSR_TAB n" cambia de pantalla y "MSR_SHOT" manda la pantalla en RGB565, franja a franja.
class Strip : public Adafruit_GFX {
 public:
  uint16_t buf[320 * 48];
  int y0 = 0;
  Strip() : Adafruit_GFX(320, 240) {}
  void drawPixel(int16_t x, int16_t y, uint16_t c) override {
    y -= y0;
    if (x >= 0 && x < 320 && y >= 0 && y < 48) buf[y * 320 + x] = c;
  }
};
void sendScreenshot() {
  Strip* st = new (std::nothrow) Strip();
  if (!st) { Serial.printf("MSR_SHOT_ERROR heap=%u\n", (unsigned)ESP.getFreeHeap()); return; }
  st->cp437(true);
  Serial.printf("MSR_SHOT_BEGIN %d %d\n", 320, 240);
  for (st->y0 = 0; st->y0 < 240; st->y0 += 48) {
    memset(st->buf, 0, sizeof(st->buf));
    gfx = st;
    drawScreen();
    gfx = &lcd;
    Serial.write((const uint8_t*)st->buf, sizeof(st->buf));
  }
  Serial.println();
  Serial.println("MSR_SHOT_END");
  delete st;
}
void pollSerial() {
  static char buf[32];
  static uint8_t len = 0;
  while (Serial.available()) {
    char c = Serial.read();
    if (c != '\n' && c != '\r') { if (len < sizeof(buf) - 1) buf[len++] = c; continue; }
    buf[len] = 0; len = 0;
    int a;
    if (sscanf(buf, "MSR_TAB %d", &a) == 1 && a >= 0 && a <= 3) { screen = a; drawScreen(); Serial.println("MSR_CMD_OK"); }
    else if (!strcmp(buf, "MSR_SHOT")) sendScreenshot();
  }
}

void loop() {
  web.handleClient();
  pollSerial();
  if (portalMode) { dns.processNextRequest(); delay(2); return; }
  handleTouch();
  if (portalMode) return;
  uint32_t ms = millis();
  if (ms - lastBright > 1500) { lastBright = ms; updateBrightness(); }
  if (WiFi.status() == WL_CONNECTED) {
    String url = "http://" + WiFi.localIP().toString() + "/";
    if (url != settingsUrl) { settingsUrl = url; drawScreen(); }
  } else if (ms - lastReconnect > 30000) { lastReconnect = ms; WiFi.reconnect(); }
  uint32_t interval = lastError[0] ? 120000UL : 1800000UL;
  if (config.town[0] && (refreshWanted || ms - lastFetchTry >= interval)) {
    putCenter(160, 188, "Actualizando precios...", ACC, 1, BG);
    refreshPrices(); drawScreen();
  }
  if (ms - lastTick > 1000) {
    lastTick = ms;
    static int lastDate = 0, lastMinute = -1;
    struct tm t;
    if (now(t)) {
      if (lastDate && ymdOf(t) != lastDate) { refreshWanted = true; drawScreen(); }
      lastDate = ymdOf(t);
      if (lastMinute != t.tm_min) { lastMinute = t.tm_min; drawHeader(); }
    }
  }
  applyLed(); delay(5);
}

