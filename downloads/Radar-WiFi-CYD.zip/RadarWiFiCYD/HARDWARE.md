# Perfil declarado CYD

ESP32-2432S028R, ILI9341 vertical 240x320 y táctil XPT2046.

LCD HSPI: SCK14, MISO12, MOSI13, CS15, DC2, BL21, RST -1.
Táctil: SCK25, MISO39, MOSI32, CS33, IRQ36.
microSD: CS5 en alto, sin montar. BOOT: GPIO0.

Otras variantes pueden tener otro panel o pines. Referencia comunitaria:
https://github.com/witnessmenow/ESP32-Cheap-Yellow-Display/blob/main/PINS.md
