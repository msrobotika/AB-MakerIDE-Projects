# Radar WiFi CYD · MS Robotika

Proyecto open source creado con AB MakerIDE SUPER. Esta descarga contiene fuentes, no firmware precompilado.

## Empezar
1. Extrae el ZIP completo. Conserva juntos RadarWiFiCYD.ino, radar_logic.h y radar_selftest.h dentro de la carpeta RadarWiFiCYD.
2. Abre RadarWiFiCYD.ino con AB MakerIDE SUPER o Arduino IDE.
3. Prepara Arduino ESP32 3.3.12 y bibliotecas Adafruit GFX 1.13.0, ILI9341 1.6.2, BusIO 1.17.4 y XPT2046_Touchscreen 1.4.
4. Selecciona el perfil esp32:esp32:jczn_2432s028r y compila. Comprueba modelo y revisión de tu propia placa antes de decidir cargarla.

Alternativa con Arduino CLI desde la carpeta que contiene RadarWiFiCYD:
`arduino-cli compile --fqbn esp32:esp32:jczn_2432s028r RadarWiFiCYD`

## Qué hace
Radar de redes WiFi de 2,4 GHz, lista por señal, detalles y controles táctiles. Retiene hasta 48 AP por BSSID. Calibración de tres cruces; mantener BOOT 1,2 s permite repetirla. Escanea pasivamente y no se asocia a las redes.

El radio indica intensidad relativa. El ángulo es decorativo: no mide metros ni dirección. El dispositivo muestra nombres y BSSID; ocúltalos antes de compartir tus fotos.

## Enlaces
- IDE y descargas: https://github.com/msrobotika/AB-MakerIDE-SUPER
- Proyecto, galería y evidencia: https://github.com/msrobotika/AB-Displays-Lab/tree/main/examples/radar-wifi-cyd
- Más proyectos del IDE: https://github.com/msrobotika/AB-MakerIDE-Projects
- Informe de compilación y límites: https://github.com/msrobotika/AB-Displays-Lab/blob/main/docs/VALIDACION.md

La evidencia del vídeo original y las autopruebas incluidas son cosas distintas. No se ha repetido una prueba física completa al preparar esta descarga. Licencia MIT para contenido propio; las bibliotecas externas mantienen sus condiciones y se instalan por separado.
