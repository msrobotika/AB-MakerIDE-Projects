# Estación meteorológica WiFi CYD · MS Robotika

1. Extrae esta carpeta completa y abre WeatherStationCYD.ino con AB MakerIDE SUPER o Arduino IDE.
2. Prepara Arduino ESP32 3.3.12, Adafruit GFX 1.13.0, ILI9341 1.6.2, BusIO 1.17.4, XPT2046_Touchscreen 1.4, ArduinoJson 7.4.2 y WiFiManager 2.0.17.
3. FQBN: esp32:esp32:jczn_2432s028r. Compila; esta descarga no graba la placa automáticamente.
4. Al ejecutar, calibra el táctil y configura tu WiFi de 2,4 GHz y ciudad desde el portal http://192.168.4.1 de la red temporal que muestra la placa. No publiques su contraseña.

Desde la carpeta que contiene WeatherStationCYD:
arduino-cli compile --fqbn esp32:esp32:jczn_2432s028r WeatherStationCYD

LCD HSPI: SCK14/MISO12/MOSI13/CS15/DC2/BL21/RST-1. Táctil: SCK25/MISO39/MOSI32/CS33/IRQ36. SD CS5 alto, sin montar. BOOT GPIO0. Perfil declarado CYD ESP32-2432S028R con ILI9341 240x320 y XPT2046.

Consulta temperatura, humedad, viento, presión y previsión de tres días mediante Open-Meteo. Datos de modelo por Internet; no sensores locales. Actualiza cada 15 minutos. Mantener BOOT 2 s o usar WIFI abre/cierra configuración.

Madrid fue la ubicación de ejemplo: existe fotografía y vídeo aportados del LCD con WIFI OK y datos recibidos. Firmware compilado y dos pruebas de contrato HTTPS desde PC correctas; no se afirma prueba física exhaustiva ni hash verificado del binario instalado.

Proyecto, pines, guía, galería y límites:
https://github.com/msrobotika/AB-Displays-Lab/tree/main/examples/weather-station-cyd

IDE: https://github.com/msrobotika/AB-MakerIDE-SUPER
Catálogo: https://github.com/msrobotika/AB-MakerIDE-Projects

Código propio MIT; dependencias con sus propias licencias. Datos Open-Meteo CC BY 4.0. La API tiene condiciones propias de uso no comercial en su modalidad gratuita y para actividades promocionales/comerciales: https://open-meteo.com/en/terms . La licencia del código no sustituye esas condiciones.
